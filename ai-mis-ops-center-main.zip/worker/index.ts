/** Cloudflare Worker entry point for the vinext-starter template. */
import { handleImageOptimization, DEFAULT_DEVICE_SIZES, DEFAULT_IMAGE_SIZES } from "vinext/server/image-optimization";
import handler from "vinext/server/app-router-entry";
import { handleSurveyRequest } from "./surveys";
import { handleTicketRequest } from "./tickets";
import { handleAdminRequest, handleSessionRequest } from "./admin";
import { handleDashboardRequest } from "./dashboard";
import { handleSupportTeamRequest } from "./support-teams";
import { handleLoginRequest, handleLogoutRequest } from "./auth";

interface Env {
  ASSETS: Fetcher;
  DB: D1Database;
  IMAGES: {
    input(stream: ReadableStream): {
      transform(options: Record<string, unknown>): {
        output(options: { format: string; quality: number }): Promise<{ response(): Response }>;
      };
    };
  };
}

interface ExecutionContext {
  waitUntil(promise: Promise<unknown>): void;
  passThroughOnException(): void;
}

// Image security config. SVG sources with .svg extension auto-skip the
// optimization endpoint on the client side (served directly, no proxy).
// To route SVGs through the optimizer (with security headers), set
// dangerouslyAllowSVG: true in next.config.js and uncomment below:
// const imageConfig: ImageConfig = { dangerouslyAllowSVG: true };

const worker = {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/api/surveys") {
      return handleSurveyRequest(request, env.DB);
    }

    if (url.pathname === "/api/tickets") {
      return handleTicketRequest(request, env.DB);
    }

    const ticketMatch = url.pathname.match(/^\/api\/tickets\/([^/]+)$/);
    if (ticketMatch) {
      return handleTicketRequest(request, env.DB, ticketMatch[1]);
    }



    if (url.pathname === "/api/support-teams") {
      return handleSupportTeamRequest(request, env.DB);
    }

    const supportTeamMatch = url.pathname.match(/^\/api\/support-teams\/([^/]+)\/members$/);
    if (supportTeamMatch) {
      return handleSupportTeamRequest(request, env.DB, supportTeamMatch[1]);
    }

    if (url.pathname === "/api/session") {
      return handleSessionRequest(request, env.DB);
    }

    if (url.pathname === "/api/auth/login") {
      return handleLoginRequest(request, env.DB);
    }

    if (url.pathname === "/api/auth/logout") {
      return handleLogoutRequest(request, env.DB);
    }

    if (url.pathname === "/api/dashboard") {
      return handleDashboardRequest(request, env.DB);
    }

    const adminMatch = url.pathname.match(
      /^\/api\/admin\/(users|roles|teams|assets|services|audit)(?:\/([^/]+))?$/,
    );
    if (adminMatch) {
      return handleAdminRequest(
        request,
        env.DB,
        adminMatch[1] as "users" | "roles" | "teams" | "assets" | "services" | "audit",
        adminMatch[2],
      );
    }

    if (url.pathname === "/_vinext/image") {
      const allowedWidths = [...DEFAULT_DEVICE_SIZES, ...DEFAULT_IMAGE_SIZES];
      return handleImageOptimization(request, {
        fetchAsset: (path) => env.ASSETS.fetch(new Request(new URL(path, request.url))),
        transformImage: async (body, { width, format, quality }) => {
          const result = await env.IMAGES.input(body).transform(width > 0 ? { width } : {}).output({ format, quality });
          return result.response();
        },
      }, allowedWidths);
    }

    return handler.fetch(request, env, ctx);
  },
};

export default worker;
